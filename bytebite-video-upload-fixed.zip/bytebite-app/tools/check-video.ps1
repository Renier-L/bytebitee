param(
  [Parameter(Mandatory=$true)]
  [string]$Video
)
Write-Host "Checking: $Video" -ForegroundColor Cyan
if (-not (Get-Command ffprobe -ErrorAction SilentlyContinue)) {
  Write-Host "ffprobe/FFmpeg is not installed. Run .\tools\install-ffmpeg-windows.ps1 first." -ForegroundColor Red
  exit 1
}
ffprobe -v error -show_entries stream=codec_name,codec_type,width,height,pix_fmt,r_frame_rate -show_entries format=duration,size -of default=noprint_wrappers=1 "$Video"
