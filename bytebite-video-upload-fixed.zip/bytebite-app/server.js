const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');
const { URL } = require('url');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DB_FILE = path.join(ROOT, 'data', 'db.json');
const UPLOAD_DIR = path.join(PUBLIC, 'uploads');
const ORIGINAL_UPLOAD_DIR = path.join(UPLOAD_DIR, '_originals');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(ORIGINAL_UPLOAD_DIR, { recursive: true });

function commandExists(command){
  try{
    const r = spawnSync(command, ['-version'], {stdio:'ignore'});
    return !r.error && r.status === 0;
  }catch{return false;}
}
const HAS_FFMPEG = commandExists('ffmpeg');
const HAS_FFPROBE = commandExists('ffprobe');

function rawBody(req,maxBytes=120*1024*1024){
  return new Promise((resolve,reject)=>{
    const chunks=[]; let bytes=0; let done=false;
    req.on('data',c=>{
      if(done) return;
      bytes += c.length;
      if(bytes > maxBytes){
        done=true;
        reject(new Error('Video is too large. Maximum upload size is 120 MB.'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end',()=>{ if(!done) resolve(Buffer.concat(chunks)); });
    req.on('error',reject);
  });
}

function runFFmpeg(input,output){
  return new Promise((resolve,reject)=>{
    const args=[
      '-y','-i',input,
      '-map','0:v:0','-map','0:a:0?',
      '-vf','scale=\'if(gt(iw,ih),min(iw,1280),min(iw,720))\':-2,fps=30',
      '-c:v','libx264','-preset','veryfast','-crf','23',
      '-pix_fmt','yuv420p',
      '-c:a','aac','-b:a','128k',
      '-movflags','+faststart',
      output
    ];
    const cp=spawn('ffmpeg',args,{windowsHide:true});
    let err='';
    cp.stderr.on('data',d=>{err+=d.toString(); if(err.length>12000) err=err.slice(-12000);});
    cp.on('error',reject);
    cp.on('close',code=>code===0?resolve():reject(new Error('Video conversion failed. '+err.slice(-700))));
  });
}

function probeVideo(file){
  if(!HAS_FFPROBE) return null;
  try{
    const r=spawnSync('ffprobe',[
      '-v','error','-select_streams','v:0',
      '-show_entries','stream=codec_name,width,height,pix_fmt,r_frame_rate:format=duration',
      '-of','json',file
    ],{encoding:'utf8',windowsHide:true});
    if(r.status!==0) return null;
    return JSON.parse(r.stdout||'{}');
  }catch{return null;}
}

function readDB(){
  const db = JSON.parse(fs.readFileSync(DB_FILE,'utf8'));
  db.users ||= []; db.sessions ||= []; db.vendors ||= []; db.meals ||= []; db.reels ||= [];
  db.trackerLogs ||= []; db.waterLogs ||= [];
  let changed=false;
  for(const u of db.users){
    if(!u.savedReels){u.savedReels=[];changed=true;}
    if(!u.dailyGoals){u.dailyGoals={calories:2000,protein:90,sodiumMg:2000,waterGlasses:8};changed=true;}
  }
  if(changed) writeDB(db);
  return db;
}
function writeDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2)); }
function json(res,status,data,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});res.end(JSON.stringify(data));}
function body(req,maxBytes=18*1024*1024){return new Promise((resolve,reject)=>{let raw='';let bytes=0;req.on('data',c=>{bytes+=c.length;if(bytes>maxBytes){reject(new Error('Request is too large.'));req.destroy();return;}raw+=c;});req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{});}catch(e){reject(new Error('Invalid JSON request.'));}});req.on('error',reject);});}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){const hash=crypto.scryptSync(password,salt,64).toString('hex');return `${salt}:${hash}`;}
function verifyPassword(password,stored){try{const [salt,hash]=stored.split(':');const test=crypto.scryptSync(password,salt,64);return crypto.timingSafeEqual(test,Buffer.from(hash,'hex'));}catch{return false;}}
function token(){return crypto.randomBytes(24).toString('hex');}
function authUser(req,db){const bearer=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!bearer)return null;const sess=db.sessions.find(s=>s.token===bearer);return sess?db.users.find(u=>u.id===sess.userId):null;}
function sanitizeUser(u){if(!u)return null;const {passwordHash,...safe}=u;return safe;}
function serveStatic(req,res,url){let pathname=decodeURIComponent(url.pathname);if(pathname==='/')pathname='/index.html';const file=path.normalize(path.join(PUBLIC,pathname));if(!file.startsWith(PUBLIC))return json(res,403,{error:'Forbidden'});fs.stat(file,(err,stat)=>{if(err||!stat.isFile()){const fallback=path.join(PUBLIC,'index.html');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return fs.createReadStream(fallback).pipe(res);}const ext=path.extname(file).toLowerCase();const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.mp4':'video/mp4','.webm':'video/webm'};const type=types[ext]||'application/octet-stream';const cache=ext==='.html'?'no-cache':'public, max-age=300';const range=req.headers.range;if(range&&(ext==='.mp4'||ext==='.webm')){const m=/bytes=(\d*)-(\d*)/.exec(range);if(!m){res.writeHead(416,{'Content-Range':`bytes */${stat.size}`});return res.end();}let start=m[1]?parseInt(m[1],10):0;let end=m[2]?parseInt(m[2],10):stat.size-1;if(Number.isNaN(start)||Number.isNaN(end)||start<0||end>=stat.size||start>end){res.writeHead(416,{'Content-Range':`bytes */${stat.size}`});return res.end();}res.writeHead(206,{'Content-Type':type,'Content-Length':end-start+1,'Content-Range':`bytes ${start}-${end}/${stat.size}`,'Accept-Ranges':'bytes','Cache-Control':cache});return fs.createReadStream(file,{start,end}).pipe(res);}res.writeHead(200,{'Content-Type':type,'Content-Length':stat.size,'Accept-Ranges':(ext==='.mp4'||ext==='.webm')?'bytes':'none','Cache-Control':cache});fs.createReadStream(file).pipe(res);});}
function todayPH(){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
function num(v,d=0){const n=Number(v);return Number.isFinite(n)?n:d;}
function clamp(v,min,max){return Math.min(max,Math.max(min,v));}
function trackerSummary(db,userId,date=todayPH()){
  const logs=db.trackerLogs.filter(x=>x.userId===userId&&x.date===date);
  const water=db.waterLogs.filter(x=>x.userId===userId&&x.date===date).reduce((s,x)=>s+x.glasses,0);
  const totals=logs.reduce((a,x)=>({calories:a.calories+x.calories*x.servings,protein:a.protein+x.protein*x.servings,sodiumMg:a.sodiumMg+x.sodiumMg*x.servings,spent:a.spent+x.price*x.servings}),{calories:0,protein:0,sodiumMg:0,spent:0});
  return {date,logs,waterGlasses:water,totals};
}
function haversine(lat1,lon1,lat2,lon2){const R=6371,toRad=x=>x*Math.PI/180,dLat=toRad(lat2-lat1),dLon=toRad(lon2-lon1);const a=Math.sin(dLat/2)**2+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));}

const sseClients=new Set();
function broadcast(type,payload={}){const msg=`event: ${type}\ndata: ${JSON.stringify({...payload,at:new Date().toISOString()})}\n\n`;for(const res of [...sseClients]){try{res.write(msg);}catch{sseClients.delete(res);}}}

async function fetchJSON(url,opts={}){const ctrl=new AbortController();const t=setTimeout(()=>ctrl.abort(),7000);try{const r=await fetch(url,{...opts,signal:ctrl.signal,headers:{'User-Agent':'ByteBite-Student-Prototype/2.0 (healthy meal discovery)',...(opts.headers||{})}});if(!r.ok)throw new Error(`Live source returned ${r.status}`);return await r.json();}finally{clearTimeout(t);}}
function normalizeOFF(p){const n=p.nutriments||{};const kcal=num(n['energy-kcal_100g'] ?? n['energy-kcal'],0);const protein=num(n.proteins_100g ?? n.proteins,0);const sodiumG=num(n.sodium_100g ?? n.sodium,0);return {barcode:p.code||'',name:p.product_name||'Unnamed food',brand:p.brands||'',nutritionGrade:(p.nutriscore_grade||'').toUpperCase(),calories100g:Math.round(kcal),protein100g:+protein.toFixed(1),sodiumMg100g:Math.round(sodiumG*1000),image:p.image_front_small_url||'',source:'Open Food Facts',basis:'per 100 g'};}

const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,`http://${req.headers.host}`);const p=url.pathname;
  if(!p.startsWith('/api/'))return serveStatic(req,res,url);
  try{
    if(req.method==='GET'&&p==='/api/events'){
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});res.write(`event: connected\ndata: ${JSON.stringify({ok:true,at:new Date().toISOString()})}\n\n`);sseClients.add(res);const ping=setInterval(()=>{try{res.write(': ping\n\n');}catch{}},25000);req.on('close',()=>{clearInterval(ping);sseClients.delete(res);});return;
    }
    const db=readDB();

    if(req.method==='GET'&&p==='/api/system/video-capabilities'){
      return json(res,200,{
        ffmpeg:HAS_FFMPEG,
        ffprobe:HAS_FFPROBE,
        uploadMaxMB:120,
        preferredVideo:'H.264/AVC + AAC in MP4, yuv420p, faststart',
        note:HAS_FFMPEG
          ? 'Uploaded videos are automatically converted to browser-safe H.264 MP4.'
          : 'FFmpeg is not installed, so videos are stored as uploaded and browser compatibility depends on the original codec.'
      });
    }

    if(req.method==='POST'&&p==='/api/auth/register'){
      const b=await body(req);if(!b.name||!b.email||!b.password)return json(res,400,{error:'Name, email, and password are required.'});if(String(b.password).length<6)return json(res,400,{error:'Password must be at least 6 characters.'});const email=String(b.email).trim().toLowerCase();if(db.users.some(u=>u.email===email))return json(res,409,{error:'Email is already registered.'});const id=crypto.randomUUID();const user={id,name:String(b.name).trim(),email,passwordHash:hashPassword(String(b.password)),budget:120,goal:'Balanced',location:'Cubao, Quezon City',dietary:'No preference',premium:false,savedReels:[],dailyGoals:{calories:2000,protein:90,sodiumMg:2000,waterGlasses:8},createdAt:new Date().toISOString()};db.users.push(user);const t=token();db.sessions.push({token:t,userId:id,createdAt:new Date().toISOString()});writeDB(db);return json(res,201,{token:t,user:sanitizeUser(user)});
    }
    if(req.method==='POST'&&p==='/api/auth/login'){
      const b=await body(req);const email=String(b.email||'').trim().toLowerCase();const user=db.users.find(u=>u.email===email);if(!user||!verifyPassword(String(b.password||''),user.passwordHash))return json(res,401,{error:'Invalid email or password.'});const t=token();db.sessions.push({token:t,userId:user.id,createdAt:new Date().toISOString()});writeDB(db);return json(res,200,{token:t,user:sanitizeUser(user)});
    }
    if(req.method==='POST'&&p==='/api/auth/logout'){const bearer=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');db.sessions=db.sessions.filter(s=>s.token!==bearer);writeDB(db);return json(res,200,{ok:true});}

    if(req.method==='GET'&&p==='/api/bootstrap'){
      const user=authUser(req,db);return json(res,200,{user:sanitizeUser(user),app:{name:'ByteBite',subscriptionPrice:99,currency:'PHP',serviceArea:'Cubao, Quezon City',dataPolicy:'Seeded meal nutrition is prototype estimate; Live Food Search is sourced from Open Food Facts.'},meals:db.meals,vendors:db.vendors,reels:db.reels,tracker:user?trackerSummary(db,user.id):null,stats:{meals:db.meals.length,vendors:db.vendors.length,reels:db.reels.length}});
    }
    if(req.method==='GET'&&p==='/api/meals')return json(res,200,db.meals);
    if(req.method==='GET'&&p==='/api/vendors')return json(res,200,db.vendors);
    if(req.method==='GET'&&p==='/api/reels')return json(res,200,db.reels);
    if(req.method==='POST'&&p==='/api/recommendations'){
      const b=await body(req);const budget=clamp(num(b.budget,120),50,1000);const goal=String(b.goal||'Balanced');const dietary=String(b.dietary||'No preference');const filtered=db.meals.filter(m=>m.price<=budget&&(goal==='Balanced'||m.goals.includes(goal))&&(dietary==='No preference'||(m.dietary||[]).includes(dietary)));const sorted=[...filtered].sort((a,b)=>b.healthScore-a.healthScore||a.price-b.price);const picks=sorted.slice(0,6);const vendorIds=[...new Set(picks.flatMap(m=>m.vendorIds))];const vendors=db.vendors.filter(v=>vendorIds.includes(v.id));return json(res,200,{budget,goal,dietary,meals:picks,vendors,exampleDailyTotal:picks.slice(0,3).reduce((s,m)=>s+m.price,0),note:'Prototype nutrition values are estimates and are not medical advice.'});
    }

    // Live public food database: Open Food Facts. Only Nutri-Score A-C items are shown.
    if(req.method==='GET'&&p==='/api/live/foods'){
      const q=String(url.searchParams.get('q')||'').trim();if(q.length<2)return json(res,400,{error:'Enter at least 2 characters.'});
      try{const fields='code,product_name,brands,nutriscore_grade,nutriments,image_front_small_url';const live=await fetchJSON(`https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(q)}&search_simple=1&action=process&json=1&page_size=30&fields=${encodeURIComponent(fields)}`);const products=(live.products||[]).map(normalizeOFF).filter(x=>['A','B','C'].includes(x.nutritionGrade)&&x.calories100g>0).slice(0,12);return json(res,200,{live:true,source:'Open Food Facts',query:q,products});}catch(e){return json(res,503,{error:'Live nutrition source is currently unreachable. Check your internet connection and try again.',details:e.message});}
    }
    if(req.method==='GET'&&p.startsWith('/api/live/barcode/')){
      const code=p.split('/').pop().replace(/\D/g,'');if(code.length<8)return json(res,400,{error:'Enter a valid barcode.'});
      try{const live=await fetchJSON(`https://world.openfoodfacts.org/api/v2/product/${code}.json`);if(!live.product)return json(res,404,{error:'Barcode was not found in Open Food Facts.'});const item=normalizeOFF({...live.product,code});if(!['A','B','C'].includes(item.nutritionGrade))return json(res,422,{error:'This product is not shown because ByteBite Healthy Mode only accepts Nutri-Score A, B, or C foods.'});return json(res,200,{live:true,product:item});}catch(e){return json(res,503,{error:'Live barcode lookup is currently unreachable.',details:e.message});}
    }
    if(req.method==='GET'&&p==='/api/live/nearby'){
      const lat=num(url.searchParams.get('lat'),NaN),lon=num(url.searchParams.get('lon'),NaN);if(!Number.isFinite(lat)||!Number.isFinite(lon))return json(res,400,{error:'Location coordinates are required.'});
      const q=`[out:json][timeout:12];(nwr(around:2500,${lat},${lon})[amenity~"restaurant|cafe"][diet:vegetarian=yes];nwr(around:2500,${lat},${lon})[amenity~"restaurant|cafe"][diet:vegan=yes];nwr(around:2500,${lat},${lon})[amenity~"restaurant|cafe"][cuisine~"vegetarian|vegan|salad|health_food",i];);out center tags 30;`;
      try{const live=await fetchJSON('https://overpass-api.de/api/interpreter',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'data='+encodeURIComponent(q)});const places=(live.elements||[]).map(e=>{const la=e.lat??e.center?.lat,lo=e.lon??e.center?.lon;if(!la||!lo)return null;return{id:String(e.id),name:e.tags?.name||'Healthy-friendly food place',type:e.tags?.cuisine||e.tags?.amenity||'food',lat:la,lon:lo,distanceKm:+haversine(lat,lon,la,lo).toFixed(2),vegetarian:e.tags?.['diet:vegetarian']||'',vegan:e.tags?.['diet:vegan']||'',source:'OpenStreetMap/Overpass'};}).filter(Boolean).sort((a,b)=>a.distanceKm-b.distanceKm).slice(0,15);return json(res,200,{live:true,source:'OpenStreetMap/Overpass',places});}catch(e){return json(res,503,{error:'Live nearby-place source is currently unreachable.',details:e.message});}
    }

    const user=authUser(req,db);if(!user)return json(res,401,{error:'Please sign in first.'});

    if(req.method==='PUT'&&p==='/api/profile'){
      const b=await body(req);for(const k of ['name','location','goal','dietary'])if(b[k]!=null)user[k]=String(b[k]).trim();if(b.budget!=null)user.budget=clamp(num(b.budget,120),50,1000);user.dailyGoals ||= {calories:2000,protein:90,sodiumMg:2000,waterGlasses:8};if(b.calories!=null)user.dailyGoals.calories=clamp(num(b.calories,2000),800,5000);if(b.protein!=null)user.dailyGoals.protein=clamp(num(b.protein,90),20,300);if(b.sodiumMg!=null)user.dailyGoals.sodiumMg=clamp(num(b.sodiumMg,2000),500,5000);if(b.waterGlasses!=null)user.dailyGoals.waterGlasses=clamp(num(b.waterGlasses,8),1,30);writeDB(db);broadcast('profile:update',{userId:user.id});return json(res,200,sanitizeUser(user));
    }
    if(req.method==='POST'&&p==='/api/subscription/activate'){user.premium=true;user.subscription={status:'active',price:99,startedAt:new Date().toISOString()};writeDB(db);return json(res,200,{message:'ByteBite Premium activated in demo mode. No payment was charged.',user:sanitizeUser(user)});}

    if(req.method==='GET'&&p==='/api/tracker/today'){return json(res,200,trackerSummary(db,user.id,String(url.searchParams.get('date')||todayPH())));}
    if(req.method==='POST'&&p==='/api/tracker/log'){
      const b=await body(req);const name=String(b.name||'').trim();if(!name)return json(res,400,{error:'Food name is required.'});const log={id:crypto.randomUUID(),userId:user.id,date:String(b.date||todayPH()),name,source:String(b.source||'Manual'),calories:clamp(num(b.calories),0,5000),protein:clamp(num(b.protein),0,500),sodiumMg:clamp(num(b.sodiumMg),0,10000),price:clamp(num(b.price),0,5000),servings:clamp(num(b.servings,1),0.1,20),createdAt:new Date().toISOString()};db.trackerLogs.push(log);writeDB(db);broadcast('tracker:update',{userId:user.id,date:log.date});return json(res,201,trackerSummary(db,user.id,log.date));
    }
    let m=p.match(/^\/api\/tracker\/meal\/([^/]+)$/);
    if(req.method==='POST'&&m){const meal=db.meals.find(x=>x.id===m[1]);if(!meal)return json(res,404,{error:'Meal not found.'});const log={id:crypto.randomUUID(),userId:user.id,date:todayPH(),name:meal.name,source:'ByteBite meal',calories:num(meal.calories),protein:num(meal.protein),sodiumMg:num(meal.sodiumMg,meal.sodium==='low'?400:650),price:num(meal.price),servings:1,createdAt:new Date().toISOString()};db.trackerLogs.push(log);writeDB(db);broadcast('tracker:update',{userId:user.id,date:log.date});return json(res,201,trackerSummary(db,user.id,log.date));}
    m=p.match(/^\/api\/tracker\/log\/([^/]+)$/);
    if(req.method==='DELETE'&&m){const before=db.trackerLogs.length;db.trackerLogs=db.trackerLogs.filter(x=>!(x.id===m[1]&&x.userId===user.id));if(db.trackerLogs.length===before)return json(res,404,{error:'Log not found.'});writeDB(db);broadcast('tracker:update',{userId:user.id,date:todayPH()});return json(res,200,trackerSummary(db,user.id));}
    if(req.method==='POST'&&p==='/api/tracker/water'){const b=await body(req);const glasses=clamp(num(b.glasses,1),-20,20);db.waterLogs.push({id:crypto.randomUUID(),userId:user.id,date:String(b.date||todayPH()),glasses,createdAt:new Date().toISOString()});writeDB(db);broadcast('tracker:update',{userId:user.id,date:String(b.date||todayPH())});return json(res,200,trackerSummary(db,user.id,String(b.date||todayPH())));}

    m=p.match(/^\/api\/reels\/([^/]+)\/(like|save)$/);
    if(req.method==='POST'&&m){const reel=db.reels.find(r=>r.id===m[1]);if(!reel)return json(res,404,{error:'Reel not found.'});if(m[2]==='like'){reel.likes=(reel.likes||0)+1;broadcast('reel:like',{reelId:reel.id,likes:reel.likes});}if(m[2]==='save'){user.savedReels=user.savedReels||[];const ix=user.savedReels.indexOf(reel.id);if(ix>=0)user.savedReels.splice(ix,1);else user.savedReels.push(reel.id);}writeDB(db);return json(res,200,{reel,saved:user.savedReels.includes(reel.id)});}
    m=p.match(/^\/api\/reels\/([^/]+)\/comments$/);
    if(req.method==='POST'&&m){const reel=db.reels.find(r=>r.id===m[1]);if(!reel)return json(res,404,{error:'Reel not found.'});const b=await body(req);const text=String(b.text||'').trim();if(!text)return json(res,400,{error:'Comment cannot be empty.'});reel.comments=reel.comments||[];reel.comments.push({id:crypto.randomUUID(),user:user.name,text,createdAt:new Date().toISOString()});writeDB(db);broadcast('reel:comment',{reelId:reel.id,count:reel.comments.length});return json(res,201,reel.comments);}
    if(req.method==='POST'&&p==='/api/reels/upload-file'){
      const userNow=authUser(req,db);
      if(!userNow)return json(res,401,{error:'Sign in first.'});
      const mealId=String(url.searchParams.get('mealId')||'');
      const title=String(url.searchParams.get('title')||'').trim().slice(0,80);
      const caption=String(url.searchParams.get('caption')||'').trim().slice(0,240);
      const healthyConfirmed=url.searchParams.get('healthyConfirmed')==='true';
      if(!healthyConfirmed)return json(res,400,{error:'Confirm that the reel is about healthy lifestyle food.'});
      const meal=db.meals.find(x=>x.id===mealId);
      if(!meal)return json(res,400,{error:'Link the reel to a ByteBite healthy meal.'});
      const contentType=String(req.headers['content-type']||'').split(';')[0].toLowerCase();
      if(!['video/mp4','video/webm','video/quicktime','application/octet-stream'].includes(contentType)){
        return json(res,415,{error:'Upload an MP4, WebM, or MOV video.'});
      }
      const buf=await rawBody(req,120*1024*1024);
      if(!buf.length)return json(res,400,{error:'The uploaded video file is empty.'});
      const sourceExt=contentType==='video/webm'?'.webm':contentType==='video/quicktime'?'.mov':'.mp4';
      const base=crypto.randomUUID();
      const originalPath=path.join(ORIGINAL_UPLOAD_DIR,base+sourceExt);
      fs.writeFileSync(originalPath,buf);

      let publicFile=base+sourceExt;
      let publicPath=path.join(UPLOAD_DIR,publicFile);
      let converted=false, conversionWarning='';
      let sourceInfo=probeVideo(originalPath);

      if(HAS_FFMPEG){
        publicFile=base+'.mp4';
        publicPath=path.join(UPLOAD_DIR,publicFile);
        try{
          await runFFmpeg(originalPath,publicPath);
          converted=true;
        }catch(err){
          conversionWarning=err.message||'Automatic conversion failed.';
          fs.copyFileSync(originalPath,publicPath=path.join(UPLOAD_DIR,base+sourceExt));
          publicFile=base+sourceExt;
        }
      }else{
        fs.copyFileSync(originalPath,publicPath);
        conversionWarning='FFmpeg is not installed on this computer. The original video was saved, but Firefox may show a black screen if it uses HEVC/H.265 or another unsupported codec.';
      }

      const finalInfo=probeVideo(publicPath)||sourceInfo;
      const reel={
        id:'r-'+crypto.randomUUID(),
        title:title||meal.name,
        creator:userNow.name,
        caption:caption||'Healthy meal inspiration',
        video:'/uploads/'+publicFile,
        mealId:meal.id,
        likes:0,comments:[],
        tags:['healthy','community','bytebite'],
        createdAt:new Date().toISOString(),
        uploadedBy:userNow.id,
        videoStatus:{
          convertedToBrowserSafeMP4:converted,
          ffmpegAvailable:HAS_FFMPEG,
          source:sourceInfo,
          final:finalInfo
        }
      };
      db.reels.unshift(reel);
      writeDB(db);
      broadcast('reel:new',{reel});
      return json(res,201,{
        reel,
        conversion:{
          ffmpegAvailable:HAS_FFMPEG,
          converted,
          warning:conversionWarning,
          finalInfo
        }
      });
    }

    if(req.method==='POST'&&p==='/api/reels/upload'){
      const b=await body(req,18*1024*1024);if(b.healthyConfirmed!==true)return json(res,400,{error:'Confirm that the reel is about healthy lifestyle food.'});const meal=db.meals.find(x=>x.id===b.mealId);if(!meal)return json(res,400,{error:'Link the reel to a ByteBite healthy meal.'});const match=String(b.videoData||'').match(/^data:(video\/(?:mp4|webm));base64,(.+)$/);if(!match)return json(res,400,{error:'Upload an MP4 or WebM video.'});const buf=Buffer.from(match[2],'base64');if(buf.length>12*1024*1024)return json(res,413,{error:'Video must be 12 MB or smaller for this prototype.'});const ext=match[1]==='video/webm'?'.webm':'.mp4';const file=crypto.randomUUID()+ext;fs.writeFileSync(path.join(UPLOAD_DIR,file),buf);const reel={id:'r-'+crypto.randomUUID(),title:String(b.title||meal.name).trim().slice(0,80),creator:user.name,caption:String(b.caption||'Healthy meal inspiration').trim().slice(0,240),video:'/uploads/'+file,mealId:meal.id,likes:0,comments:[],tags:['healthy','community','bytebite'],createdAt:new Date().toISOString(),uploadedBy:user.id};db.reels.unshift(reel);writeDB(db);broadcast('reel:new',{reel});return json(res,201,reel);}

    return json(res,404,{error:'API route not found.'});
  }catch(e){console.error(e);return json(res,500,{error:e.message||'Server error.'});}
});
server.listen(PORT,()=>console.log(`ByteBite Live running on http://localhost:${PORT}`));
