# ByteBite Live — Full-Stack Healthy Lifestyle Food Platform

ByteBite Live is a dependency-free Node.js prototype based on the ByteBite concept in the supplied PDF: a healthy meal generator and budget locator for students and young professionals in Cubao, Quezon City. This upgraded build adds a daily meal tracker, TikTok-style healthy-food reels, user video uploads, live public nutrition lookup, barcode lookup, live healthy-friendly nearby place discovery, and server-sent real-time updates.

## Run

Requires Node.js 18+.

```bash
node server.js
```

Open: `http://localhost:3000`

## Core working features

- Register/login with scrypt password hashing and server sessions
- Healthy meal generator filtered by budget and goal
- Daily Meal Tracker: calories, protein, sodium, spending and water
- One-tap `Reel → Tracker` and `Meal → Tracker`
- TikTok/Reels-style vertical video feed with autoplay/pause, mute/unmute, likes, comments, saves and sharing
- Upload community healthy-food MP4/WebM reels up to 12 MB
- Real-time Server-Sent Events so likes/comments/new reels/tracker updates propagate without manual refresh
- Live Open Food Facts text search with Healthy Mode filtering to Nutri-Score A/B/C
- Live Open Food Facts barcode lookup
- Browser geolocation + OpenStreetMap/Overpass lookup for nearby places explicitly tagged vegetarian/vegan/salad/health-food
- Profile + user-configurable tracker goals
- ₱99/month Premium demo mode (no real payment charged)
- Responsive desktop/mobile interface

## Accuracy / data-source behavior

1. The built-in ByteBite meal and vendor dataset is prototype/demo data based on the project concept. It is explicitly labeled as such in the UI.
2. The Live Food Data screen requests current public product data from Open Food Facts at runtime. It requires internet access.
3. Nearby live place lookup requests OpenStreetMap/Overpass data at runtime and only shows places carrying relevant healthy/vegetarian/vegan map tags. It requires internet access and browser location permission.
4. Nutrition values from Open Food Facts are shown per 100 g. ByteBite does not silently convert them to a serving size.
5. Daily nutrition targets are user-configurable prototype settings and are not medical prescriptions.

## Real-time behavior

The app uses Server-Sent Events at `/api/events`. Open the site in two browser tabs and actions such as likes, comments, new reel posts, and tracker updates are broadcast live.

## Video behavior

Four local MP4 demo videos are included under `public/assets/videos/`, so the reel feed works offline. Signed-in users can also upload their own healthy-food MP4/WebM reel from the Reels page.


## Video playback fix
The built-in Node server now supports HTTP byte-range requests for MP4/WebM files, which browsers use for reliable HTML5 video playback. Built-in reels also include food-image posters and local H.264/YUV420P MP4 files.


## 1,000 Healthy Food Dataset Integration

This version already includes the 1,000-food ByteBite dataset in `data/db.json`.

- The existing reel-linked meals are preserved so Reel → Tracker still works.
- The database contains exactly 1,000 meal records.
- Meal Generator recommendations automatically search these records by budget and health goal.
- Meal Tracker can log any recommended meal.
- Built-in nutrition and price values are prototype estimates for academic/software demonstration.
- Live Food Data remains separate and uses Open Food Facts when internet access is available.

Run:
```bash
node server.js
```

Then open:
`http://localhost:3000`


## Video Upload Fix (40-second / real footage)

This build changes Reel uploads from Base64 JSON to direct binary uploads (up to 120 MB).

### Automatic compatibility conversion
If `ffmpeg` is available on the computer, every uploaded MP4/WebM/MOV is automatically converted to:
- H.264/AVC video
- yuv420p pixel format
- AAC audio
- 30 FPS
- MP4 with `faststart`

This is the safest combination for Firefox/Chrome/Edge.

### Windows one-time setup
From the project folder in PowerShell:
```powershell
powershell -ExecutionPolicy Bypass -File .	ools\install-ffmpeg-windows.ps1
```
After installation, close VS Code completely, reopen it, and verify:
```powershell
ffmpeg -version
```

Then:
```powershell
node server.js
```

Upload the real food video again. ByteBite will convert it automatically before publishing it.
