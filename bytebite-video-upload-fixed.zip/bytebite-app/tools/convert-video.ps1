param(
  [Parameter(Mandatory=$true)]
  [string]$InputVideo,
  [string]$OutputVideo = "bytebite-browser-safe.mp4"
)
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Write-Host "FFmpeg is not installed. Run .\tools\install-ffmpeg-windows.ps1 first." -ForegroundColor Red
  exit 1
}
ffmpeg -y -i "$InputVideo" -map 0:v:0 -map "0:a:0?" -vf "scale='if(gt(iw,ih),min(iw,1280),min(iw,720))':-2,fps=30" -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart "$OutputVideo"
Write-Host "Created: $OutputVideo" -ForegroundColor Green
