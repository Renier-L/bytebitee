Write-Host "Installing FFmpeg for ByteBite..." -ForegroundColor Green
if (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
    Write-Host ""
    Write-Host "Installation requested. CLOSE VS Code completely and reopen it so PATH refreshes." -ForegroundColor Yellow
    Write-Host "Then test: ffmpeg -version" -ForegroundColor Cyan
} else {
    Write-Host "winget was not found. Install FFmpeg manually from https://ffmpeg.org/download.html and add it to PATH." -ForegroundColor Red
}
